
$('.counter').counterUp({
    delay: 2,
    time: 2500
});


$('.counter-bis').counterUp({
    delay: 3,
    time: 1500
});